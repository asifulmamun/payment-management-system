<?php 
	function title(){$title = "Iftar Party - Kuliarchar Pilot High School";echo $title;}
	function admin(){$admin = "asifulmamun";echo $admin;}
	function password(){$password = "asifulmamun";echo $password;}
	function memberText(){$memberText = "Kuliarchar Pilot All Freinds Iftar Party - Date Fixed 14 June, 2018. Place BRTC (Beside Of Upazilla Parisad) - Desing By - <b title='https://facebook.com/asifulmamun'><a style='color:green;' href='https://facebook.com/asifulmamun'>Al Mamun</a></b>";echo $memberText;}
	function sliderImage1(){$sliderImage1 = "https://s22.postimg.cc/h9rrng71d/kpmhs-science.jpg";echo $sliderImage1;}
	function sliderImage2(){$sliderImage2 = "https://s22.postimg.cc/alv618l2p/gajipur.jpg";echo $sliderImage2;}
	function sliderImage3(){$sliderImage3 = "https://s22.postimg.cc/wnq1otklt/10688110_372526022906672_3719608041250507427_o.jpg";echo $sliderImage3;}
       
       //variable        
       $paidMax = 100;
 ?>
