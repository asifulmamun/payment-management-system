	<br><br><br>
	<footer class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<span>Design By <a href="https://facebook.com/asifulmamun">AL MAMUN</a></span>
			</div>
		</div>
	</footer>
	<br>

	<!-- jQuery -->
    <script src="../assest/js/jquery.min.js"></script>
    <!-- bootstrap -->
    <script src="../assest/js/bootstrap.min.js"></script>
    <!-- theme -->
    <script src="../assest/js/wow.js"></script>
    <!-- theme -->
    <script src="../assest/js/main.js"></script>
</body>
</html>
